﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Threading;
using Yanesdk.Network;
using Yanesdk.Math;
using Yanesdk.Ytl;

namespace NetmoduleTest
{
	public partial class Form1 : Form
	{
		public Form1()
		{

			// localhost
			// network.SetHostName("127.0.0.1" , 1000);
			network.SetHostName("127.0.0.1" , 1000);

			InitializeComponent();
		}

		private const int maxPacketSize = 100000;
		
		private LinkedList<ConnectionStruct> handles = new LinkedList<ConnectionStruct>();
		class ConnectionStruct
		{
			public ConnectionStruct(long handle , RandMaker rand_maker1 , RandMaker rand_maker2)
			{
				this.handle = handle;
				this.rand_maker1 = rand_maker1;
				this.rand_maker2 = rand_maker2;
			}
			public long handle;
			public RandMaker rand_maker1; // read用
			public RandMaker rand_maker2; // write用
		}

		private void timer1_Tick(object sender , EventArgs e)
		{
			if ( isListen )
			{
				while ( true )
				{
					long handle = network.Listen();
					if ( handle == 0 )
						break;
					// listen出来る限りする。

					handles.AddLast(new ConnectionStruct(handle , null , new RandMaker(seed)));
					{
						// 先頭に乱数seedを含めて送る
						byte[] data = new byte[4];
						MemoryCopy.SetInt(data , 0 , seed);
						network.Write(handle , data);
						dataSendTotal += data.Length;

						seed++;
					}
				}
			}

			// 受信テスト
			{
				LinkedListNode<ConnectionStruct> node = handles.First;
				while ( node != null )
				{
					LinkedListNode<ConnectionStruct> node2 = node.Next;
					byte[] data;
				Retry:
					if ( network.Read(node.Value.handle , out data) != 0 )
					{
						handles.Remove(node);
					}
					else
					{
						if ( data != null )
						{
							dataRecieveTotal += data.Length;

							// 乱数が設定されていない
							if ( node.Value.rand_maker1 == null )
							{
								// この1つめに来る4バイトは、seedに違いない
								if ( data.Length != 4 )
								{
									Console.WriteLine("seedが来ていない");
									throw null;
								}

								int s = MemoryCopy.GetInt(data , 0);
								node.Value.rand_maker1 = new RandMaker(s); // 乱数seedとして設定

							}
							else
							{

								// 読み込む必要ありき
								RandMaker r = node.Value.rand_maker1;
								if ( data.Length != ( uint ) r.GetInt() % maxPacketSize )
								{
									Console.WriteLine("サイズがおかしい");
									throw null;
								}

								for ( int i = 0 ; i < data.Length ; ++i )
								{
									if ( data[i] != ( byte ) r.GetInt() )
									{
										Console.WriteLine("データがおかしい");
										throw null;
									}
								}
								Console.WriteLine("Recieve Ok LEngth = {0}",data.Length.ToString());
								goto Retry;
							}
						}
					}
					node = node2;
				}
			}

			// 送信テスト
			{
				if ( !isListen || (sendCount++ % 100) == 0)

				{
					LinkedListNode<ConnectionStruct> node = handles.First;
					while ( node != null )
					{
						LinkedListNode<ConnectionStruct> node2 = node.Next;

						// 書き込む必要ありき
						RandMaker r = node.Value.rand_maker2;
						byte[] data = new byte[( uint ) r.GetInt() % maxPacketSize];
						for ( int i = 0 ; i < data.Length ; ++i )
						{
							data[i] = ( byte ) r.GetInt();
						}

						dataSendTotal += data.Length;

						if ( !isListen )
						{	// Listenモードでなければここで適宜待つ。
							r.Sleep();
						}

						if ( network.Write(node.Value.handle , data) != 0 )
						{
							handles.Remove(node);
						}
						// writeした直後に試しにdataにゴミを入れてみる
						for (int i = 0; i < data.Length; ++i)
							data[i] = 0xcc;

						node = node2;
					}
				}
			}

			label1.Text = "やり取りしたデータ長 Send/Recieve: " + dataSendTotal.ToString() + "/"+
				dataRecieveTotal.ToString()
				+ "\r\n確立しているconnection数 : " + handles.Count.ToString();

		}

		// 乱数seed
		private int seed;
		
		// listenモード時の送信はゆるめる
		private int sendCount;

		// やりとりしたデータ長さ
		private long dataSendTotal;
		private long dataRecieveTotal;

		private Network network = new Network();

		private bool isListen = false;
		private void button1_Click(object sender , EventArgs e)
		{
			isListen ^= true;
			if ( !isListen )
			{	// 全切断
				foreach ( ConnectionStruct node in handles )
					network.Disconnect(node.handle);
			}

			button1.Text = isListen ? "Listen中断" : "Listen開始";
		}

		private bool isConnection = false;
		private void button2_Click(object sender , EventArgs e)
		{
		//	isConnection ^= true;
		//	button2.Text = isConnection ? "Connect中断" : "Connect開始";

		//	if ( isConnection )
			{
				long handle = network.Connect();
				handles.AddLast(new ConnectionStruct(handle , null , new RandMaker(seed)));
				{
					// 先頭に乱数seedを含めて送る
					byte[] data = new byte[4];
					MemoryCopy.SetInt(data , 0 , seed);
					network.Write(handle , data);
					dataSendTotal += data.Length;

					seed++;
				}
			}
		}

	}

	/// <summary>
	///  乱数発生器
	/// </summary>
	public class RandMaker
	{
		public RandMaker(int seed)
		{
			rand = new Rand(seed);
			rand2 = new Rand(seed + 1);
		}

		public int GetInt()
		{
			return (int)rand.GetRand();
		}

		public void Sleep()
		{
			Thread.Sleep((int)((uint)rand2.GetRand() % 2000));
		}
			
		private Rand rand;
		private Rand rand2;
	}
}